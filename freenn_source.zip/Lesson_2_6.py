import numpy as np

# Создание одномерного массива
arr1 = np.array([1, 2, 3, 4, 5])
print(arr1)

# Создание двумерного массива
arr2 = np.array([[1, 2, 3], [4, 5, 6]])
print(arr2)
print(arr2.shape)

# Создание массива с нулями
zeros = np.zeros((3, 3))
print(zeros)

# Создание массива с единицами
ones = np.ones((2, 2))
print(ones)

print(np.ones_like(zeros))

# Создание массива со случайными числами
random_arr = np.random.rand(2, 3)
print(random_arr)

# Математические операции
arr3 = np.array([1, 2, 3])
arr4 = np.array([4, 5, 6])

result = arr3 + arr4
print(result)

result = arr3 - arr4
print(result)

result = arr3 * arr4
print(result)

result = arr3 / arr4
print(result)

# Индексация и срезы
element = arr1[2]
print(element)

subarray = arr2[0]
print(subarray)

slice = arr1[1:4]
print(slice)

# Индексация с условием
mask = arr1 > 2
print(mask)
masked_data = arr1[mask]
print(masked_data)
print(arr1[arr1 > 2])

# Математические функции
mean = np.mean(arr1)
print(mean)

std = np.std(arr1)
print(std)

max_value = np.max(arr1)
print(max_value)

min_value = np.min(arr1)
print(min_value)

# Скалярное произведение
print(arr3)
print(arr4)

dot = arr3.dot(arr4)
print(dot)

arr3 = np.array([[1, 2], [3, 4]])
arr4 = np.array([[3, 4], [5, 6]])
print(arr3.dot(arr4))

# Транспонирование матрицы
transposed = arr2.T
print(arr2)
print(transposed)
print(transposed.T)
