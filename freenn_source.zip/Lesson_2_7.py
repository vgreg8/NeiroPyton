import numpy as np


def neural_network(inp, weights):
    prediction_h = inp.dot(weights[0])
    prediction_out = prediction_h.dot(weights[1])
    return prediction_out


inp = np.array([50, 165])
weights_h_1 = [0.2, 0.1]
weights_h_2 = [0.3, 0.1]

weights_out_1 = [0.4, 0.2]
weights_out_2 = [0.5, 0.3]

weights_h = np.array([weights_h_1, weights_h_2]).T
weights_out = np.array([weights_out_1, weights_out_2]).T

weights = [weights_h, weights_out]

print(neural_network(inp, weights))
