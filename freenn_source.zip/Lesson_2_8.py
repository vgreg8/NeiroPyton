import numpy as np

def neural_network(inp, weights):
    return inp.dot(weights)


def get_error(true_prediction, prediction):
    return (true_prediction - prediction) ** 2


prediction = neural_network(np.array([150, 40]), [0.2, 0.3])
true_prediction = 50
print(get_error(true_prediction, prediction))
